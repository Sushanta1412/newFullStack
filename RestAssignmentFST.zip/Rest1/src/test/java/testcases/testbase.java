package testcases;

import static io.restassured.RestAssured.given;
import static org.testng.Assert.assertEquals;

import java.io.IOException;

import io.restassured.response.Response;

public class testbase {

	public void getMethodGenaric(String url,String param1) throws IOException
	{
    	Response res=given().when().get(url);
    	
    	System.out.println(res.asString());
    	System.out.println(res.path(param1).toString());
    	assertEquals(res.statusCode(), 200);
	}
}
