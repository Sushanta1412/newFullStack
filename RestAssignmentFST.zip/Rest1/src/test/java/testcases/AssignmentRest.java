package testcases;

import java.io.IOException;

import org.testng.annotations.Test;

public class AssignmentRest extends Testbaseswagger {
	
	@Test(description="to perform Methods of Swagger")
	public void performTest()
	{
		//get User Details
		this.get_GetUser("https://petstore.swagger.io/v2/user/user1", "message", 404);
		
		//creating user
		this.post_CreateUser("{\r\n  \"id\": 0,\r\n  \"username\": \"ABC\",\r\n  \"firstName\": \"Abc\",\r\n  \"lastName\": \"Bcd\",\r\n  \"email\": \"abc@bbc.com\",\r\n  \"password\": \"abcbbc1\",\r\n  \"phone\": \"1234567890\",\r\n  \"userStatus\": 0\r\n}", "https://petstore.swagger.io/v2/user", "Content-Type","application/json", 200);
		//Response resp=given().body("{\r\n  \"id\": 0,\r\n  \"username\": \"ABC\",\r\n  \"firstName\": \"Abc\",\r\n  \"lastName\": \"Bcd\",\r\n  \"email\": \"abc@bbc.com\",\r\n  \"password\": \"abcbbc1\",\r\n  \"phone\": \"1234567890\",\r\n  \"userStatus\": 0\r\n}").header("Content-Type","application/json").when().post("https://petstore.swagger.io/v2/user");
	
	}
	
	@Test(description="to post with JSON file")
	public void postJson() throws IOException
	{
		this.post_CreateUserWithJsonFile("https://petstore.swagger.io/v2/user", "postdata.json", "Content-Type","application/json", 200);
		//FileInputStream file =new FileInputStream(new File(System.getProperty("user.dir")+"\\data\\postData.json"));
		//Response resp=given().body(IOUtils.toString(file)).header("Content-Type","application/json").when().post("https://reqres.in/api/users");
	}

	@Test(description="to Put with or without JSON file")
	public void putJson() throws IOException
	{
		this.putmethodwithoutJson("{\r\n  \"id\": 0,\r\n  \"username\": \"ABC\",\r\n  \"firstName\": \"Abc\",\r\n  \"lastName\": \"Bcd\",\r\n  \"email\": \"abc@bbc.com\",\r\n  \"password\": \"abcbbc1\",\r\n  \"phone\": \"1234567890\",\r\n  \"userStatus\": 0\r\n}", "https://petstore.swagger.io/v2/user/sandy", "Content-Type","application/json", 200);
		this.putmethodwithJsonFile("https://petstore.swagger.io/v2/user/sandy", "postdata.json", "Content-Type","application/json", 200);
		//FileInputStream file =new FileInputStream(new File(System.getProperty("user.dir")+"\\data\\postData.json"));
		//Response resp=given().body(IOUtils.toString(file)).header("Content-Type","application/json").when().post("https://reqres.in/api/users");
	}

}
