package testcases;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

import static io.restassured.RestAssured.given;

import org.apache.commons.io.IOUtils;

import io.restassured.response.Response;

import org.testng.annotations.Test;
import static org.testng.Assert.assertEquals;

public class Testbaseswagger {
	
	public void get_GetUser(String url, String msg, int statusCode)
	{
		Response resp=given().when().get(url);
		System.out.println("Response Body :"+resp.asString());
		System.out.println("Message :"+resp.path(msg).toString());
		assertEquals(resp.getStatusCode(),statusCode);
	}
	
	public void post_CreateUser(String jsonBody, String url, String contentType, String contentAppl, int statusCode)
	{
		Response resp=given().body(jsonBody).header(contentType,contentAppl).when().post(url);
		System.out.println("Response Body :"+resp.asString());
		assertEquals(resp.getStatusCode(),statusCode);
		System.out.println("Status Code:"+resp.getStatusCode());

	}
	
	public void post_CreateUserWithJsonFile(String url, String fileName, String contentType, String contentAppl, int statusCode) throws IOException
	{
		FileInputStream file =new FileInputStream(new File(System.getProperty("user.dir")+"\\data\\"+fileName));
		Response resp=given().body(IOUtils.toString(file)).header(contentType,contentAppl).when().post(url);
		System.out.println("Response :"+ resp.asString());
		assertEquals(resp.getStatusCode(),statusCode);
	}

	public void putmethodwithoutJson(String jsonBody,String url, String contentType, String contentAppl, int statusCode)
	{
		Response resp=given().body(jsonBody).header(contentType,contentAppl).when().put(url);
		System.out.println("Response Body :"+resp.asString());
		assertEquals(resp.getStatusCode(),statusCode);
		System.out.println("Status Code:"+resp.getStatusCode());
	}
	
	public void putmethodwithJsonFile(String url, String fileName, String contentType, String contentAppl, int statusCode) throws IOException
	{
		FileInputStream file =new FileInputStream(new File(System.getProperty("user.dir")+"\\data\\"+fileName));
		Response res=given().body(IOUtils.toString(file)).header(contentType,contentAppl).when().put(url);
		System.out.println(res.asString());
	}

}
