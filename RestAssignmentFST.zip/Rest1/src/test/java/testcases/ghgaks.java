package testcases;

import static io.restassured.RestAssured.given;
import static org.testng.Assert.assertEquals;

import java.io.IOException;

import org.testng.annotations.Test;

import io.restassured.response.Response;

public class ghgaks extends testbase {

	
	@Test(description = "put method with Json file")
	public void get() throws IOException
	{
		
		this.getMethodGenaric("https://reqres.in/api/users/2","data.email");
		
	}

}
